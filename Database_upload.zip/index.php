<?php
include"config.php";
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<?php

if(isset($_POST['but_upload'])){
 
  $filename = $_FILES['file']['name'];
  $target_dir = "upload/";
  if($filename !=''){
    $target_file = $target_dir . basename($_FILES["file"]["name"]);

    // file extension 
    $extensions = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    
    // Valid file extensions
  $extensions_arr = array("jpg","jpeg","png","gif");
   // Check extension
   if( in_array($extensions,$extensions_arr) ){
    //convert to base64
    $image_base64 = base64_encode(file_get_contents($_FILES['file']['tmp_name']));
    $image = "data::image/".$extensions.";base64,".$image_base64;

    //store image to upload folder
    if(move_uploaded_file($_FILES['file']['tmp_name'], $target_file)){
      // Insert record
     $query = "INSERT INTO images(name,image) VALUES ('".$filename."','".$image."')"; 
     //$query = "INSERT INTO images(image) VALUES ('".$image."')";
     mysqli_query($con,$query);
   // }
  }
 
     // Upload file
    // move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);

  }
 
}
} 
?>
</head>
<body>


<form method="post" action="" enctype='multipart/form-data'>
  <input type='file' name='file' />
  <input type='submit' value='Upload' name='but_upload'>
</form>
</body>
</html>