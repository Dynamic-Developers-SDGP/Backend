<?php
include "config.php";
$images_sql = "SELECT * from images ORDER BY id desc limit 1 ";
$result = mysqli_query($con,$images_sql);
$row = mysqli_fetch_array($result);
$filename = $row['name'];
$image = $row['image'];
?>

<!DOCTYPE html>
<html>
<head>
     <title></title>
</head>
<body>
     <!-- Image -->
    <!-- <image src = "upload/<?= $filename?>" width='300px' height='300px'>-->
     <br><br>
     <!-- Base64 image -->
     <img src ="<?=$image?>"width='300px' height='300px'>
</body>
</html>
